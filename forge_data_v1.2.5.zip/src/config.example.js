// Example configuration
// Copy this file to config.js and fill in your values

export const GA_CONFIG = {
    MEASUREMENT_ID: 'YOUR_MEASUREMENT_ID',
    API_SECRET: 'YOUR_API_SECRET'
};
